# SYSGUARD

Linux 系统安全检测

## 编译

安装 devtoolset-6, 启用后再编译

    scl enable devtoolset-6 bash
